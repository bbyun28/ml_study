def mutate_protein(protein_sequence):
    return protein_sequence.replace('T', 'S')