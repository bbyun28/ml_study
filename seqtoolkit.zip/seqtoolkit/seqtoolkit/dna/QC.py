def sequence_length(sequence):
    return len(sequence)

def gc_content(sequence):
    gc_count = sequence.count('G') + sequence.count('C')
    return (gc_count / len(sequence)) * 100

def missing_ratio(sequence):
    missing_count = sequence.count('N')
    return (missing_count / len(sequence)) * 100