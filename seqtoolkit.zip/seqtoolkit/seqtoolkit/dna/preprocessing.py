from .QC import missing_ratio

def process_sequence(sequence):
    miss_ratio = missing_ratio(sequence)
    if miss_ratio > 50:
        return None
    elif miss_ratio <= 5:
        return sequence
    else:
        # 누락된 비율이 5% 이하가 될 때까지 오른쪽 끝에서 서열 하나씩 제거
        while miss_ratio > 5 and len(sequence) > 0:
            sequence = sequence[:-1]
            miss_ratio = missing_ratio(sequence)
            if miss_ratio <= 5:
                return sequence
                break